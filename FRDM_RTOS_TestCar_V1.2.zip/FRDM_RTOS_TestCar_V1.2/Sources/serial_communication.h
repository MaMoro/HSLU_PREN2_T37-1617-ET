/*
 * serial_communication.h
 *
 *  Created on: Feb 23, 2017
 *      Author: pirzi
 */

#ifndef SERIAL_COMMUNICATION_H_
#define SERIAL_COMMUNICATION_H_

#include <stdlib.h>

void startCommunication(void);

void refreshTasks(void);
void taskDone(uint8_t taskNbr);


#endif /* SERIAL_COMMUNICATION_H_ */
