
#ifndef __frtos_tasks_H
#define __frtos_tasks_H

void CreateTasks(void);
void CreateTask2(void);
void CreateTask3(void);
void CreateTask4(void);
void CreateTask5(void);
void CreateTask6(void);
void CreateTask7(void);

#endif
